# Starfall Command — Android prototype

This is an original, independent offline fleet strategy game, **not Crying Suns**. No original game files, names, artwork, or story are copied.

## Included
- Procedural 3x3 star map with connected jumps and sectors
- Fuel, scrap, hull, salvage, random encounters
- Touch-based tactical combat, defense, retreat, repair and refuel
- Offline persistent local save
- Android landscape WebView shell

## Test in browser
Open `app/src/main/assets/index.html` in a modern browser.

## Build Android APK without a PC
1. Create a GitHub repository and upload the files, including `.github/workflows/build-apk.yml` (keep the folder structure).
2. In GitHub Actions, run `Build Android APK`.
3. Download `Starfall-Command-debug-APK` from the completed workflow artifacts.
4. Install the debug APK on your own Android device. It is signed with a debug key for testing, not a release signing key.

Build requires internet on GitHub runners to download Gradle/Android dependencies. The installed game does not require internet. The APK has not been compiled or device-tested in this environment.
